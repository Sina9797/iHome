export default function Loading() {
    return  "welcome" 
  }