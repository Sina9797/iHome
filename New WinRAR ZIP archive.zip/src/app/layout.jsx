import { Geist, Geist_Mono } from "next/font/google";
import "./globals.scss";
import Header from "@/components/templates/header/Header";
import Footer from "@/components/templates/footer/Footer";
import { Suspense } from "react";
import Loading from "./loading";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: "iHome",
  icons: {
    icon: "/avatar.webp",
  },
  openGraph: {
    title: "iHome",
    description: "iHome",
    url: "https://inja.liara.run",
    metadataBase: new URL("https://inja.liara.run"),
    siteName: "iHome",
    creator: "iHome",
    images: [
      {
        url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRaT0P-6IszbiD5EWig4DDPa6iUKJHGyXufFw&s",
        width: 800,
        height: 600,
      },
    ],
    locale: "en_US",
    type: "website",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="fa">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  );
}
