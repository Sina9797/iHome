import "./globals.scss";
import React from 'react';
import Home from "@/components/templates/home/Home";
import "bootstrap/dist/css/bootstrap.min.css";  



function page() {
  return (
    <>
      <Home/>
    </>
  )
}

export default page
