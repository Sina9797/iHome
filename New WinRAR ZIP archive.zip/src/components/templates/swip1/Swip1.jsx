import React, { useState, useEffect } from "react";
import styles from "./swip1.module.scss";
import Link from "next/link";
import "keen-slider/keen-slider.min.css";
import { useKeenSlider } from "keen-slider/react";
import Image from "next/image";
import { BsChevronRight, BsChevronLeft } from "react-icons/bs";
function Swip() {
  const [sliderRef, instanceRef] = useKeenSlider({
    loop: true,
    slides: {
      perView: 3,
      spacing: 30,
    },
  });

  const handlePrevClick = () => {
    if (instanceRef.current) instanceRef.current.prev();
  };

  const handleNextClick = () => {
    if (instanceRef.current) instanceRef.current.next();
  };

  return (
    <>
      <div className={`${styles.AC} d-none d-lg-flex d-xl-none`}>
        <div className={styles.AD}>
          <button
            className={`${styles.ZZZ} keen-slider-prev`}
            onClick={handlePrevClick}
          >
            <BsChevronLeft style={{ fontSize: "20px" }} />
          </button>
          <div ref={sliderRef} className={`keen-slider ${styles.mySwiper}`}>
            <div className="keen-slider__slide">
              <Link href="/">
                <div className={`${styles.AE} card`}>
                  <Image src="/house.jpg" width={900} height={900} alt="..." />
                  <h4>Esplanade</h4>
                  <h6>Los Angeles</h6>
                </div>
              </Link>
            </div>
            <div className="keen-slider__slide">
              <Link href="/">
                <div className={`${styles.AE} card`}>
                  <Image src="/13.webp" width={900} height={900} alt="..." />
                  <h4>Aden South</h4>
                  <h6>New York</h6>
                </div>
              </Link>
            </div>
            <div className="keen-slider__slide">
              <Link href="/">
                <div className={`${styles.AE} card`}>
                  <Image src="/14.jpg" width={900} height={900} alt="..." />
                  <h4>Scenic Terrace</h4>
                  <h6>Texas</h6>
                </div>
              </Link>
            </div>
            <div className="keen-slider__slide">
              <Link href="/">
                <div className={`${styles.AE} card`}>
                  <Image src="/15.jpg" width={900} height={900} alt="..." />
                  <h4>Ardisia Park</h4>
                  <h6>New Mexico</h6>
                </div>
              </Link>
            </div>
            <div className="keen-slider__slide">
              <Link href="/">
                <div className={`${styles.AE} card`}>
                  <Image src="/1.jpg" width={900} height={900} alt="..." />
                  <h4>Yardly Mount</h4>
                  <h6>Miami</h6>
                </div>
              </Link>
            </div>
            <div className="keen-slider__slide">
              <Link href="/">
                <div className={`${styles.AE} card`}>
                  <Image src="/5.jpg" width={900} height={900} alt="..." />
                  <h4>Timber Ridge</h4>
                  <h6>Chicago</h6>
                </div>
              </Link>
            </div>
          </div>
          <button
            className={`${styles.ZZZ} keen-slider-next`}
            onClick={handleNextClick}
          >
            <BsChevronRight style={{ fontSize: "20px" }} />
          </button>
        </div>
      </div>
    </>
  );
}

export default Swip;
