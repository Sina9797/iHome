import React from "react";
import styles from "./footer.module.scss";
import Link from "next/link";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faLocation,
  faLocationDot,
  faPhone,
  faSitemap,
} from "@fortawesome/free-solid-svg-icons";
import { faMap, faMessage } from "@fortawesome/free-regular-svg-icons";
import Image from "next/image";
import { color } from "framer-motion";

function Footer() {
  return (
    <>
      <div className={styles.AJ}>
        <div>
          <span>QUICK ACCESS</span>
          <Link style={{ color: "black", textDecoration: "none" }} href="/">
            Buy
          </Link>
          <Link style={{ color: "black", textDecoration: "none" }} href="/">
            Sell
          </Link>
          <Link style={{ color: "black", textDecoration: "none" }} href="/">
            Rent
          </Link>
          <Link style={{ color: "black", textDecoration: "none" }} href="/">
            COMMERCILinkL{" "}
          </Link>
        </div>
        <div>
          <span>Cities</span>
          <Link style={{ color: "black", textDecoration: "none" }} href="/">
            pLinkris
          </Link>
          <Link style={{ color: "black", textDecoration: "none" }} href="/">
            MLinkdrid
          </Link>
          <Link style={{ color: "black", textDecoration: "none" }} href="/">
            Stockholm
          </Link>
        </div>
        <div>
          <span>iHome</span>
          <Link style={{ color: "black", textDecoration: "none" }} href="/">
            ContLinkct Us
          </Link>
          <Link style={{ color: "black", textDecoration: "none" }} href="/">
            Linkbout Us
          </Link>
          <Link style={{ color: "black", textDecoration: "none" }} href="/">
            Our Convertor
          </Link>
          <Link style={{ color: "black", textDecoration: "none" }} href="/">
            Turres{" "}
          </Link>
        </div>
        <div>
          <span>iHome</span>
          <div className={styles.AK}>
            <Link href={""}>
              <Image src="/FF.jpg" width={900} height={900} alt="..." />
            </Link>
            <Link href={""}>
              <Image src="/EE.png" width={900} height={900} alt="..." />
            </Link>
            <Link href={""}>
              <Image src="/GG.png" width={900} height={900} alt="..." />
            </Link>
            <Link href={""}>
              <Image src="/HH.png" width={900} height={900} alt="..." />
            </Link>
          </div>
          <div className="mt-3">
            <Link style={{ color: "black", textDecoration: "none" }} href="/">
              <FontAwesomeIcon className={styles.AM} icon={faPhone} /> +99 676
              767 767
            </Link>
            <Link style={{ color: "black", textDecoration: "none" }} href="/">
              <FontAwesomeIcon icon={faMessage} /> www.iHOME.com
            </Link>
            <Link style={{ color: "black", textDecoration: "none" }} href="/">
              <FontAwesomeIcon icon={faLocationDot} /> wdw wewe dwdw
            </Link>
          </div>
        </div>
        <div className={styles.AL}>
          <span>Applications</span>
          <Link href={""}>
            <Image src="/apple.png" width={900} height={900} alt="..." />
          </Link>
          <Link href={""}>
            <Image src="/play.webp" width={900} height={900} alt="..." />
          </Link>
        </div>
      </div>
    </>
  );
}

export default Footer;
