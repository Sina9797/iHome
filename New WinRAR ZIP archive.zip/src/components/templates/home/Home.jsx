"use client";
import React from "react";
import Swip from "@/components/templates/swip/Swip";
import Swip1 from "@/components/templates/swip1/Swip1";
import Swip2 from "@/components/templates/swip2/Swip2";
import Swip3 from "@/components/templates/swip3/Swip3";
import Link from "next/link";
import Image from "next/image";
import Skeleton from "@/components/modules/skeleton/Skeleton";
import { BsChevronRight } from "react-icons/bs";
import { BsSearch } from "react-icons/bs";
import {
  faChevronLeft,
  faChevronRight,
  faSearch,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import { useState } from "react";

function Home() {
  const handleImageLoad = () => {
    setLoading(false);
  };
  const [isLoading, setIsLoading] = useState(true);

  const [isHidden1, setIsHidden1] = useState(false);

  const toggleSlide1 = () => {
    setIsHidden1(!isHidden1);
  };
  const A = ["APARTMENT", "HOUSE", "COMMERCIAL", "RENT"];
  const B = [
    "FLOOR MATERIAL",
    "HOT WATER SUPPLIER",
    "COOLING SYSTRM",
    "HEATING SYSTEM",
  ];
  const C = [
    {
      id: 1,
      name: "FLOOR MATERIAL",
      Options: ["A", "B", "C"],
    },
    {
      id: 2,
      name: "HOT WATER SUPPLIER",
      Options: ["A", "B", "C"],
    },
    {
      id: 3,
      name: "COOLING SYSTRM",
      Options: ["A", "B", "C"],
    },
    {
      id: 4,
      name: "HEATING SYSTEM",
      Options: ["A", "B", "C"],
    },
  ];
  const D = ["ELAVATOR", "PARKING", "WAREHOUSE", "BALCONY"];
  const Fo = [
    {
      Picture: "/1.jpg",
      id: 1,
      description: "Bethany Crossing Townhomes",
      city: "Chicago",
      price: "$ 700.000",
    },
    {
      Picture: "/2.webp",
      id: 2,
      description: "South River Terrace",
      city: "Los Angeles",
      price: "$ 850.000",
    },
    {
      Picture: "/3.webp",
      id: 3,
      description: "Lolich Farms",
      city: "New York",
      price: "$ 750.000",
    },
    {
      Picture: "/5.jpg",
      id: 4,
      description: "The Townhomes at Anthem Park",
      city: "New Mexico",
      price: "$ 1.750.000",
    },
    {
      Picture: "/6.jpg",
      id: 5,
      description: "The Townhomes at Westview",
      city: "Texas",
      price: "$ 650.000",
    },
    {
      Picture: "/7.jpeg",
      id: 6,
      description: "Scenic Terrace",
      city: "Las Vegas",
      price: "$ 780.000",
    },
    {
      Picture: "/8.jpg",
      id: 7,
      description: "Aden South at Westview",
      city: "Arizona",
      price: "$ 920.000",
    },
    {
      Picture: "/9.jpg",
      id: 8,
      description: "Liberty Preserve",
      city: "Miami",
      price: "$ 1.750.000",
    },
    {
      Picture: "/10.webp",
      id: 9,
      description: "Esplanade at Westview",
      city: "New York",
      price: "$ 550.000",
    },
  ];

  return (
    <>
      <div id="G">
        {isHidden1 ? (
          <div id="BB">
            <div className="header">
              <span>WHAT'S ON YOUR MIND?</span>
              <div id="H">
                <input
                  className="form-control "
                  placeholder="Search In iHome"
                  aria-label="Search"
                />

                <BsSearch />
              </div>
            </div>
            <div id="K">
              <div id="M">
                {A.map((item) => (
                  <div id="N">
                    <span id="ZIB" htmlFor={item}>
                      {item}
                    </span>
                    <input
                      id="J"
                      className="form-check-input"
                      type="checkbox"
                    />
                  </div>
                ))}
              </div>
              <div id="P">
                {C.map((item) => (
                  <div id="S">
                    <span id="zam">{item.name}</span>
                    <select id="R">
                      {item.Options.map((option) => (
                        <option>{option}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>
              <div id="MM" className="me-0">
                {D.map((item) => (
                  <div id="N">
                    <span id="ZIB" htmlFor={item}>
                      {item}
                    </span>
                    <input
                      id="J"
                      className="form-check-input"
                      type="checkbox"
                    />
                  </div>
                ))}
              </div>
            </div>
            <div id="L">
              <div id="LLL">
                <span>AREA</span>
                <sub className="ms-5">BETWEEN</sub>
              </div>
              <div id="LL">
                <input type="number" />
                <span>&</span>
                <input type="number" />
              </div>
              <div id="LLLL">
                <span>ROOM</span>
                <input type="number" />
              </div>
            </div>
            <button
              style={{ border: "1px solid black" }}
              onClick={toggleSlide1}
            >
              HIDE ADVANCED OPTION
            </button>
          </div>
        ) : (
          <div id="AA">
            <div className="header">
              <span>WHAT'S ON YOUR MIND?</span>
              <div id="H">
                <input
                  className="form-control "
                  placeholder="Search In iHome"
                  aria-label="Search"
                />

                <BsSearch />
              </div>
            </div>
            <div id="I">
              <div>
                <input id="J" className="form-check-input" type="checkbox" />
                <span htmlFor="J">APARTMENT</span>
              </div>
              <div>
                <input id="J" className="form-check-input" type="checkbox" />
                <span htmlFor="J">HOUSE</span>
              </div>
              <div>
                <input id="J" className="form-check-input" type="checkbox" />
                <span htmlFor="J">COMMERCIAL</span>
              </div>
              <div>
                <input id="J" className="form-check-input" type="checkbox" />
                <span htmlFor="J">RENT</span>
              </div>
            </div>
            <button
              style={{ border: "1px solid black" }}
              onClick={toggleSlide1}
            >
              SHOW ADVANCED OPTION
            </button>
          </div>
        )}
      </div>

      <span id="U">SUGGESTIONS</span>
      <span id="V">
        Lorem ipsum dolor sit amet. consectetur elit. sed do eiusmod tempor
        incididunt ut labore.
      </span>
      <div id="WW">
        {" "}
        <div id="WWW"></div>{" "}
        <div id="W">
          {" "}
          {Fo.map((item) => (
            <div className="card shadow-lg" key={item.id}>
              {" "}
              <div href="/">
                {isLoading && <Skeleton />}
                <Image
                  src={item.Picture}
                  className="card-img-top"
                  width={900}
                  height={900}
                  alt="..."
                  onLoadingComplete={() => setIsLoading(false)}
                />{" "}
                <h4 id="gheym">{item.price}</h4>{" "}
                <h3 className="card-text">{item.description}</h3>{" "}
                <p className="card-text">{item.city}</p>{" "}
                <h5 className="card-text">
                  {" "}
                  <Link href="">BUY</Link>{" "}
                </h5>{" "}
              </div>{" "}
            </div>
          ))}{" "}
        </div>{" "}
      </div>

      <div id="Y">
        <div id="ZZ">
          <button>
            <b>Buy & Sell </b>
            <BsChevronRight style={{ fontSize: "20px" }} />
          </button>
          <button>
            {" "}
            <b>Rent </b>
            <BsChevronRight style={{ fontSize: "20px" }} />
          </button>
          <button>
            {" "}
            <b>Show</b> <BsChevronRight style={{ fontSize: "20px" }} />
          </button>
          <button>
            {" "}
            <b>Price List </b>
            <BsChevronRight style={{ fontSize: "20px" }} />
          </button>
          <button>
            {" "}
            <b> Particiption </b>
            <BsChevronRight style={{ fontSize: "20px" }} />
          </button>
        </div>
        <div id="Z">
          {" "}
          <Image src="/17.jpg" width={900} height={900} alt="..." />
        </div>
      </div>

      <h5 id="AB">Our Pics</h5>
      <Swip />
      <Swip1 />
      <Swip2 />
      <Swip3 />
      <div id="AF"></div>
      <h2 id="AG">ABOUT iHOME</h2>
      <div id="AH">
        <span>
          eevevev egeweeeee eeerrrb rwrjowj jnvojovn nevjnov jnvoeovnonvn
          njvnononvnnv jnvoonvnvnj nvonovnv nvinvnnvn jnocnonc nconeonco
          eocooncenc
        </span>
        <span>
          mvlmvkmlmv mvllmv mkvlklv mvmmv mvklvm mvlmlmv mlvmmv mvlmlmv{" "}
        </span>
        <span>
          vpmvmvmkmv vvmkvmmkvmmv mvkmkmvmmvmmv mvkmmvmvm mvkkvmmkmv mkmkmkmm
          mkvmkmkm mkvmmmvm
        </span>
        <span>vlklnv vmklkmmvk mvkmmvm mvkmmv mvmmlv vmlkv mvklv</span>
        <span>
          vmvmkvmmvm mvkmkmkmv mkvmlkmlkvm lkmvkkmkmvm kmvkmlkkmv mvkmmlv
          mvlkklvm
        </span>
      </div>

      <div id="AI">
        <Image src="/BB.jpg" width={900} height={900} alt="..." />
        <Image src="/CC.jpg" width={900} height={900} alt="..." />
        <Image src="/DD.jpg" width={900} height={900} alt="..." />
      </div>
    </>
  );
}

export default Home;
