"use client";
import React, { useState } from "react";
import { faBars } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import styles from "./header.module.scss";
import Link from "next/link";
import Image from "next/image";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import { Pagination } from "swiper/modules";

function Header() {
  const [isOpen, setIsOpen] = useState(false);

  // More descriptive function name
  const handleToggle = () => {
    setIsOpen((prev) => !prev);
  };

  return (
    <div className={styles.A}>
      <div
        className={`${styles.keshoo} d-md-none ${isOpen ? styles.Active : ""}`}
      >
        <div className={styles.birr}>
          <span>iHOME</span>
          <FontAwesomeIcon
            className={styles.btn}
            icon={faBars}
            onClick={handleToggle}
          />
        </div>
        <div className={styles.birrr}>
          <div className={styles.zoro}>
            {/* Ensure 'href' attributes are valid links */}
            <span>
              <Link className={styles.Fff} href="#">
                VIP
              </Link>
            </span>
            <span>
              <Link className={styles.Fff} href="#">
                CLUBS
              </Link>
            </span>
            <span>
              <Link className={styles.Fff} href="#">
                BLOGS
              </Link>
            </span>
            <span>
              <Link className={styles.Fff} href="#">
                NEWS
              </Link>
            </span>
          </div>
          <div className={styles.zoroo}>
            <div className={styles.C}>
              <Image src="/avatar.webp" width={40} height={40} alt="..." />
            </div>
            <span>
              <Link className={styles.LI} href="#">
                Michael
              </Link>
            </span>
          </div>
        </div>
      </div>

      <div className={`${styles.header} d-none d-md-flex`}>
        <div className={styles.D}>
          <div className={styles.C}>
            <Image src="/avatar.webp" width={40} height={40} alt="..." />
          </div>
          <span>
            <Link href="#">Michael</Link>
          </span>
        </div>
        <div className={styles.E}>
          <span>
            <b>iHOME</b>
          </span>
        </div>
        <div className={styles.F}>
          <Link className={styles.Ff} href="#">
            VIP
          </Link>
          <Link className={styles.Ff} href="#">
            CLUBS
          </Link>
          <Link className={styles.Ff} href="#">
            BLOGS
          </Link>
          <Link className={styles.Ff} href="#">
            NEWS
          </Link>
        </div>
      </div>

      <div className={styles.B}>
        <Swiper
          spaceBetween={30}
          slidesPerView={1}
          loop={true}
          pagination={{ clickable: true }}
          modules={[Pagination]}
        >
          <SwiperSlide>
            <Image src="/2.webp" width={900} height={900} alt="Slide 1" />
          </SwiperSlide>
          <SwiperSlide>
            <Image src="/9.jpg" width={900} height={900} alt="Slide 2" />
          </SwiperSlide>
          <SwiperSlide>
            <Image src="/16.jpg" width={900} height={900} alt="Slide 3" />
          </SwiperSlide>
        </Swiper>
      </div>
    </div>
  );
}

export default Header;
